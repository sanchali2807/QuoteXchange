const { RFQ } = require("../models");


const parseLocal = (val) => {
  const s = String(val).replace("T", " ").slice(0, 19);

  const [datePart, timePart] = s.split(" ");
  const [y, m, d] = datePart.split("-").map(Number);
  const [hh, mm, ss] = timePart.split(":").map(Number);

  return new Date(y, m - 1, d, hh, mm, ss);
};

const getISTNow = () => {
  return new Date(
    new Date().toLocaleString("en-US", {
      timeZone: "Asia/Kolkata",
    })
  );
};

const fixIST = (val) => {
  const d = new Date(val);
  d.setMinutes(d.getMinutes() - 330);
  return d;
};

const getAuctionStatus = (rfq) => {
  const now = getISTNow();

  const start = parseLocal(rfq.startTime);
  const close = parseLocal(rfq.endTime);
  const forced = parseLocal(rfq.forcedCloseTime);

  if (now < start) return "UPCOMING";

  // Only when DB values were updated to forced close
  if (
    rfq.wasExtended &&
    close.getTime() === forced.getTime()
  ) {
    return "FORCED CLOSED";
  }

  if (now > close) return "CLOSED";

  if (rfq.wasExtended) return "EXTENDED";

  return "ACTIVE";
};



const isInsideTriggerWindow = (rfq) => {
  const now = getISTNow();
  const close = parseLocal(rfq.endTime);

  const diffTime = (close - now) / (1000 * 60);

  console.log("NOW:", now);
  console.log("CLOSE:", close);
  console.log("DIFF MIN:", diffTime);
  console.log("X MIN:", rfq.xMinutes);

  return diffTime <= Number(rfq.xMinutes) && diffTime >= 0;
};



const checkAndExtendAuction = async (
  rfqId,
  oldRank,
  newRank,
  prevL1,
  currL1
) => {
  const rfq = await RFQ.findByPk(rfqId);
  if (!rfq) return false;

  const now = getISTNow();
  const forced = parseLocal(rfq.forcedCloseTime);
  const currentClose = parseLocal(rfq.endTime);

  if (now > forced) return false;

  if (currentClose.getTime() === forced.getTime()) {
    return false;
  }

  if (!isInsideTriggerWindow(rfq)) return false;

  const oldOrder = oldRank.join(",");
  const newOrder = newRank.join(",");

  const orderChanged = oldOrder !== newOrder;
  const l1Changed = prevL1 !== currL1;

  let shouldExtend = false;

  switch (rfq.triggerType) {
    case "BID_LAST_X":
      shouldExtend = true;
      break;

    case "RANK_CHANGE":
      shouldExtend = orderChanged;
      break;

    case "L1_CHANGE":
      shouldExtend = l1Changed;
      break;

    case "ANY":
      shouldExtend = true;
      break;

    default:
      shouldExtend = false;
  }

  if (!shouldExtend) return false;

  let newClose = parseLocal(rfq.endTime);

  newClose.setMinutes(
    newClose.getMinutes() + Number(rfq.yMinutes)
  );

  if (newClose > forced) {
    newClose = forced;
  }

  await rfq.update({
    endTime: fixIST(newClose),
    wasExtended: true,
  });

  return true;
};

module.exports = {
  parseLocal,
  getISTNow,
  fixIST,
  getAuctionStatus,
  checkAndExtendAuction,
};