const jwt = require("jsonwebtoken");

const generateToken = (user)=>{
    return jwt.sign(
        {
            // PAYLOAD
            id : user.id,
            name : user.name,
            email : user.email,
            role : user.role
        },
        // SECRET KEY
        process.env.JWT_SECRET,
        // OPTIONS
        {
            expiresIn : "3d"
        }
    );
}
module.exports = generateToken;